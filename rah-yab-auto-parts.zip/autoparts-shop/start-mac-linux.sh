#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required / نصب Node.js لازم است: https://nodejs.org"
  exit 1
fi
if [ ! -d node_modules ]; then npm install; fi
if [ ! -f data/store.sqlite ]; then npm run seed; fi
npm run launch
