require('../scripts/env');
const fs=require('fs'),path=require('path'),initSqlJs=require('sql.js');
const file=path.join(__dirname,'..','data','store.sqlite'); fs.mkdirSync(path.dirname(file),{recursive:true});
let db, ready;
const schema=`PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,phone TEXT DEFAULT '',role TEXT DEFAULT 'customer',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS addresses(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,title TEXT DEFAULT 'خانه',receiver TEXT NOT NULL,phone TEXT NOT NULL,province TEXT NOT NULL,city TEXT NOT NULL,address TEXT NOT NULL,postal_code TEXT DEFAULT '',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,slug TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS car_brands(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS car_models(id INTEGER PRIMARY KEY AUTOINCREMENT,brand_id INTEGER NOT NULL,name TEXT NOT NULL,years TEXT DEFAULT '1385-1405',FOREIGN KEY(brand_id) REFERENCES car_brands(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,slug TEXT UNIQUE NOT NULL,description TEXT DEFAULT '',category_id INTEGER,car_brand_id INTEGER,car_model_id INTEGER,part_brand TEXT DEFAULT '',oem_code TEXT DEFAULT '',price INTEGER NOT NULL DEFAULT 0,discount INTEGER NOT NULL DEFAULT 0,stock INTEGER NOT NULL DEFAULT 0,image TEXT DEFAULT '/images/part-placeholder.svg',images TEXT DEFAULT '[]',specs TEXT DEFAULT '{}',compatibility TEXT DEFAULT '[]',featured INTEGER DEFAULT 0,sold INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL,FOREIGN KEY(car_brand_id) REFERENCES car_brands(id) ON DELETE SET NULL,FOREIGN KEY(car_model_id) REFERENCES car_models(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,tracking_code TEXT UNIQUE NOT NULL,status TEXT DEFAULT 'pending',subtotal INTEGER NOT NULL,shipping INTEGER NOT NULL,total INTEGER NOT NULL,payment_method TEXT NOT NULL,payment_status TEXT DEFAULT 'unpaid',receiver TEXT NOT NULL,phone TEXT NOT NULL,address TEXT NOT NULL,city TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER,product_name TEXT NOT NULL,price INTEGER NOT NULL,quantity INTEGER NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY, sess TEXT NOT NULL, expired INTEGER NOT NULL);
`;
function persist(){fs.writeFileSync(file,Buffer.from(db.export()));}
async function init(){if(ready)return ready;ready=(async()=>{const SQL=await initSqlJs();db=fs.existsSync(file)?new SQL.Database(fs.readFileSync(file)):new SQL.Database();db.exec(schema);persist();})();return ready;}
function all(sql,params=[]){const st=db.prepare(sql);st.bind(params);let a=[];while(st.step())a.push(st.getAsObject());st.free();return a;}
function get(sql,params=[]){return all(sql,params)[0]||null;}
function run(sql,params=[]){db.run(sql,params);const id=get('SELECT last_insert_rowid() AS id')?.id;persist();return {lastInsertRowid:id,changes:db.getRowsModified()};}
module.exports={init,all,get,run,persist,get db(){return db;},file};
