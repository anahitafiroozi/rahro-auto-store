@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js نصب نیست. لطفاً از https://nodejs.org نصب کنید.
  echo Node.js is required. Download it from https://nodejs.org
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 (echo نصب وابستگی‌ها ناموفق بود. & pause & exit /b 1)
)
if not exist data\store.sqlite (
  echo Creating sample database...
  call npm run seed
  if errorlevel 1 (echo ساخت پایگاه داده ناموفق بود. & pause & exit /b 1)
)
call npm run launch
echo Site launcher stopped. Close this window to stop.
pause
