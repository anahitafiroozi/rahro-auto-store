# راه‌یاب یدک | RahYab Auto Parts

فروشگاه اینترنتی قطعات خودرو با رابط فارسی و راست‌چین، قالب‌های EJS، سرور Express و پایگاه داده SQLite مبتنی بر `sql.js` (بدون نیاز به کامپایل افزونه بومی). این پروژه یک نقطه شروع عملی برای فروشگاه است؛ پیش از استفاده تجاری واقعی، تنظیمات امنیتی، سیاست‌های ارسال/مرجوعی، درگاه پرداخت و نسخه پشتیبان را مطابق کسب‌وکار خود بازبینی کنید.

## امکانات اصلی
- صفحه اصلی با دسته‌بندی‌ها، پرفروش‌ها، تازه‌ترین محصولات و تخفیف‌ها
- جست‌وجوی زنده و فیلتر بر اساس دسته، برند خودرو، مدل، برند قطعه، قیمت و موجودی؛ مرتب‌سازی و صفحه‌بندی
- صفحه محصول با کد OEM، سازگاری، مشخصات و تصاویر
- سبد خرید نشست‌محور برای مهمان و حساب کاربری، نشانی‌ها، تاریخچه سفارش و رهگیری
- پرداخت در محل و صفحه شبیه‌سازی‌شده پرداخت اینترنتی (بدون دریافت وجه واقعی)
- پنل مدیریت محافظت‌شده در `/admin`: محصولات، دسته‌ها، خودروها، سفارش‌ها، مشتریان و تنظیمات
- اعتبارسنجی ورودی‌ها، پرس‌وجوهای پارامتری، هش رمز با bcryptjs، CSRF، Helmet، محدودیت تلاش ورود و اعتبارسنجی نوع/حجم تصاویر
- ۵۰ محصول نمونه، ۱۱ دسته و ۸ برند خودرو با مدل‌های نمونه

## فناوری‌ها
Node.js 18+، Express، EJS، `sql.js`, `express-session`, `bcryptjs`, `multer`, Helmet. نیازی به build step نیست. پایگاه داده در `data/store.sqlite` ذخیره می‌شود؛ برای نوشتن، فایل پایگاه داده به‌روزرسانی می‌شود.

## شروع سریع
```bash
npm install
npm run seed
npm start
```
سپس آدرس `http://localhost:3000` را باز کنید. اگر `.env` وجود نداشته باشد، برنامه به صورت خودکار از `.env.example` یک نسخه می‌سازد و `SESSION_SECRET` تصادفی می‌گذارد. برای تغییر پورت یا اطلاعات ورود، `.env` را ویرایش کنید.

## How to run with one click / اجرای یک‌کلیکی

### Windows
1. ZIP را Extract کنید.
2. اگر Node.js نصب نیست، از [nodejs.org](https://nodejs.org) نسخه LTS را نصب کنید.
3. روی `start-windows.bat` دوبار کلیک کنید. وابستگی‌ها و داده نمونه در اولین اجرا نصب/ایجاد می‌شوند، سرور اجرا می‌شود و مرورگر باز می‌شود.

### macOS / Linux
1. Node.js 18 یا جدیدتر نصب باشد.
2. در ترمینال وارد پوشه پروژه شوید و اجرا کنید:
   ```bash
   chmod +x start-mac-linux.sh start-mac.command
   ./start-mac-linux.sh
   ```
   در macOS می‌توانید روی `start-mac.command` دوبار کلیک کنید (ممکن است تنظیمات امنیتی macOS تأیید اجرای فایل را بخواهد). سرور با `Ctrl+C` متوقف می‌شود.

### Android phone (Termux)
1. برنامه Termux را از [F-Droid](https://f-droid.org/packages/com.termux/) نصب کنید.
2. فایل ZIP را به گوشی منتقل و در یک پوشه قابل دسترسی استخراج کنید. در صورت نیاز به دسترسی حافظه، در Termux دستور `termux-setup-storage` را اجرا کنید.
3. داخل پوشه پروژه اجرا کنید:
   ```bash
   bash start-android-termux.sh
   ```
   اسکریپت در صورت نیاز Node.js را با `pkg install nodejs -y` نصب می‌کند، وابستگی‌ها را نصب و پایگاه داده را seed می‌کند و سرور را در پس‌زمینه اجرا می‌کند. اگر `termux-open-url` در دسترس باشد مرورگر باز می‌شود؛ در غیر این صورت به `http://localhost:3000` بروید.
4. برای توقف، از پوشه پروژه `kill $(cat .server.pid)` اجرا کنید. در صورت نیاز `pkill -f 'node app.js'` نیز قابل استفاده است.

### iPhone / iOS
iOS به شکل معمول امکان اجرای محلی یک سرور Node.js مانند این پروژه را فراهم نمی‌کند. گزینه جایگزین، استقرار روی هاست است:
- **Render:** پروژه را در GitHub قرار دهید، یک Web Service بسازید، Build Command را `npm install && npm run seed` و Start Command را `npm start` بگذارید. متغیرهای `SESSION_SECRET`، `ADMIN_USERNAME` و `ADMIN_PASSWORD` را در Environment تنظیم کنید. برای استفاده پایدار، دیسک پایدار متصل کنید؛ فایل SQLite روی فایل‌سیستم موقت ممکن است با استقرار مجدد پاک شود.
- **Railway:** پروژه را از GitHub Deploy کنید، Start Command را `npm start` تنظیم کنید و متغیرهای محیطی بالا را اضافه کنید. برای ماندگاری SQLite، Volume را به مسیر `data` متصل کنید. قبل از استفاده واقعی، ماندگاری فایل و نسخه پشتیبان را آزمایش کنید.

> **مهم:** `localhost` یعنی همان دستگاهی که سرور را اجرا کرده است. اجرای سایت روی رایانه، به‌طور خودکار آن را روی گوشی باز نمی‌کند. برای بازکردن سایت روی گوشی متصل به همان Wi‑Fi، IP محلی رایانه را پیدا کنید (مثلاً `192.168.1.25`) و در گوشی `http://192.168.1.25:3000` را باز کنید. سرور روی `0.0.0.0` گوش می‌دهد و IP شبکه را در خروجی چاپ می‌کند. فایروال باید اجازه اتصال به پورت انتخابی را بدهد و هر دو دستگاه روی شبکه قابل دسترس باشند.

## اطلاعات ورود نمونه
- **مدیر:** نام کاربری `admin`، رمز `Admin12345!` (در اولین اجرا از `.env.example` خوانده می‌شود؛ فوراً تغییر دهید).
- **مشتری نمونه:** `customer@example.com`، رمز `Customer123!`.

اگر متغیرهای `ADMIN_USERNAME` و `ADMIN_PASSWORD` را بعد از ایجاد کاربر مدیر تغییر دهید، رمز موجود در پایگاه داده خودکار تغییر نمی‌کند. برای نصب جدید قبل از seed مقدارها را تعیین کنید یا رمز مدیر را در پایگاه داده/فرایند مدیریت امن خود تغییر دهید.

## افزودن محصول از پنل
1. به `/admin/login` بروید و وارد شوید.
2. از «محصولات» گزینه «افزودن محصول» را بزنید.
3. نام، قیمت به تومان، تخفیف، موجودی، دسته، برند خودرو، مدل، کد OEM و سازگاری را وارد کنید.
4. مشخصات فنی را به صورت JSON معتبر وارد کنید، برای نمونه `{"جنس":"استاندارد","گارانتی":"اصالت کالا"}`.
5. حداکثر ۶ تصویر با فرمت تصویری مجاز و اندازه حداکثر ۳ مگابایت انتخاب کنید و ذخیره کنید. محصول بلافاصله در سایت عمومی نمایش داده می‌شود.

## ساختار پوشه‌ها
```text
app.js                 سرور و مسیرهای فروشگاه و مدیریت
models/db.js           لایه SQLite / sql.js
scripts/env.js         ایجاد خودکار .env
scripts/seed.js        داده‌های نمونه
scripts/launch.js      راه‌انداز بین‌پلتفرمی
routes/ controllers/   محل توسعه ساختار مسیرها/کنترلرها
views/                 قالب‌های EJS و partialها
public/css/            استایل RTL
public/js/             جست‌وجوی زنده
public/images/         لوگو، بنر و SVGهای نمونه
public/fonts/          محل فایل‌های محلی فونت Vazirmatn
uploads/               تصاویر آپلودشده توسط مدیر
data/                  پایگاه داده SQLite ساخته‌شده هنگام seed
start-windows.bat      لانچر ویندوز
start-mac-linux.sh     لانچر macOS/Linux
start-mac.command      لانچر دوبارکلیک macOS
start-android-termux.sh لانچر Termux
```

## تصاویر نمونه و فونت
تصاویر نمونه به صورت SVG محلی هستند تا محصول‌ها تصویر شکسته نداشته باشند. پوشه `public/fonts` برای فونت Vazirmatn در نظر گرفته شده است؛ در محیط ساخت این بسته دسترسی شبکه برای دریافت فایل فونت فراهم نبود، بنابراین فایل‌های فونت اصلی داخل ZIP قابل گنجاندن نبودند و مرورگر از فونت‌های فارسی نصب‌شده/جایگزین استفاده می‌کند. برای الزام استفاده از Vazirmatn به‌صورت کاملاً آفلاین، فایل‌های مجاز `Vazirmatn-Regular.woff2` و `Vazirmatn-Bold.woff2` را از توزیع رسمی Vazirmatn در `public/fonts/` قرار دهید.

## Screenshots / تصاویر
پس از اجرای محلی، از صفحه اصلی، صفحه محصول، سبد خرید و داشبورد مدیریت اسکرین‌شات اضافه کنید.

## نکات پیش از استفاده واقعی
- درگاه پرداخت این پروژه صرفاً نمایشی است و پرداخت آنلاین واقعی ندارد.
- برای استقرار عمومی، از HTTPS، مدیریت امن secrets، بکاپ زمان‌بندی‌شده و پایگاه داده پایدار استفاده کنید؛ در صورت رشد فروشگاه، SQLite را با دیتابیس مدیریت‌شده جایگزین کنید.
- احراز هویت پنل با نقش مدیر و نشست محافظت‌شده است؛ دسترسی شبکه‌ای عمومی را فقط پس از تغییر رمزهای نمونه و بررسی امنیت استقرار فعال کنید.

---

# English

RahYab Auto Parts is a Persian, RTL, server-rendered auto-parts store built with Node.js, Express, EJS and SQLite through `sql.js` (no native compilation). It includes product discovery and vehicle filters, live search, cart and checkout, customer accounts, order tracking, a demo-only payment screen, and a role-protected admin area.

## Install and run
```bash
npm install
npm run seed
npm start
```
Open `http://localhost:3000`. If `.env` is missing, it is created from `.env.example` with a random `SESSION_SECRET`. Use Node.js 18 or newer.

## How to run with one click
- **Windows:** unzip the project and double-click `start-windows.bat`. Install Node.js from https://nodejs.org first if needed.
- **macOS/Linux:** run `chmod +x start-mac-linux.sh start-mac.command`, then `./start-mac-linux.sh` (or double-click `start-mac.command` on macOS).
- **Android:** install Termux from F-Droid, copy and unzip the project, then run `bash start-android-termux.sh`. Open `http://localhost:3000` if the browser does not open automatically. Stop it with `kill $(cat .server.pid)`.
- **iPhone/iOS:** a local Node.js server is not a practical supported option. Deploy from GitHub to Render or Railway, set `npm install && npm run seed` as the build command and `npm start` as the start command, configure environment variables, and attach persistent storage for the SQLite `data` directory. Test persistence after redeploys.

**Localhost note:** `localhost` refers to the device running the server. A computer and phone do not share a localhost server. To access it from another device on the same Wi-Fi, open `http://COMPUTER-LAN-IP:3000` on the phone. The server binds to `0.0.0.0`; allow the port through your firewall.

## Demo credentials
- Admin username: `admin`
- Admin password: `Admin12345!`
- Sample customer: `customer@example.com` / `Customer123!`

Change default credentials before public deployment. The payment gateway is intentionally simulated and does not process money. Product images are local SVGs. The build environment had no network access to fetch Vazirmatn font binaries; the CSS references local files under `public/fonts`, but the official `.woff2` files must be supplied there for fully offline Vazirmatn rendering. Add screenshots after running the application.

## Add a product
Sign in at `/admin/login`, open Products → Add product, fill in the price, stock, OEM code, category, vehicle fitment and valid JSON specs, optionally upload up to six images (3 MB each), and save. Changes appear on the public catalog immediately.

## License
MIT. See `LICENSE`.
