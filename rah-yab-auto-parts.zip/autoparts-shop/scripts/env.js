const fs=require('fs'),crypto=require('crypto');
if(!fs.existsSync('.env')) { let s=fs.readFileSync('.env.example','utf8').replace('replace-this-with-a-long-random-secret',crypto.randomBytes(32).toString('hex')); fs.writeFileSync('.env',s,{flag:'wx'}); console.log('Created .env from .env.example'); }
