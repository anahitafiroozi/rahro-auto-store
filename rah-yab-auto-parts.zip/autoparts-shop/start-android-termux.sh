#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v pkg >/dev/null 2>&1; then echo "این فایل را داخل Termux اجرا کنید. Install/run this inside Termux."; exit 1; fi
if ! command -v node >/dev/null 2>&1; then echo "Installing Node.js..."; pkg update -y; pkg install nodejs -y; fi
if [ ! -d node_modules ]; then npm install; fi
if [ ! -f data/store.sqlite ]; then npm run seed; fi
if [ -f .server.pid ] && kill -0 "$(cat .server.pid)" 2>/dev/null; then echo "Server already running, PID $(cat .server.pid)"; else
  nohup npm start > server.log 2>&1 & echo $! > .server.pid
fi
sleep 2
URL="http://localhost:${PORT:-3000}"
echo "سایت اجرا شد: $URL"
echo "برای توقف: kill \$(cat .server.pid)  (or run: pkill -f 'node app.js')"
if command -v termux-open-url >/dev/null 2>&1; then termux-open-url "$URL" || echo "Open $URL in your browser"; else echo "Browser URL: $URL"; fi
