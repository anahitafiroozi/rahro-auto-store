Vazirmatn font files belong in this directory:
- Vazirmatn-Regular.woff2
- Vazirmatn-Bold.woff2
The build environment used to assemble this project had no network access, so official font binaries could not be bundled. CSS references these exact local paths and falls back to installed Persian fonts until the files are supplied.
